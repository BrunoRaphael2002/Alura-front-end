import livro from '../../imagens/livro.png'

export const livros = [
    {nome: 'Liderança em Design', src: livro, id: 1},
    {nome: 'Cangaceiro JavaScript: Uma aventura no sertão da programação', src: livro, id: 3},
    {nome: 'Apache Kafka e Spring Boot', src: livro, id: 4}
]